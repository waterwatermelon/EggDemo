// plugin里面注册使用的插件
exports.nunjucks ={
    enable:true,
    package:'egg-view-nunjucks'
}
exports.ejs ={
    enable:true,
    package:'egg-view-ejs'
}
exports.mysql = {
    enable:true,
    package:'egg-mysql',
}
